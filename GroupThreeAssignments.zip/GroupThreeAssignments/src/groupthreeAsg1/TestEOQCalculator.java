package groupthreeAsg1;

import java.util.Scanner;

public class TestEOQCalculator {

	public static void main(String[] args) {
		//Welcome Message
		System.out.println("Welcome to the EOQ Calculator prepared by Bin Wu, Michael Cuervo, and Paige Martin - (Group 3)\n" + 
				"Enter q to quit or the name of the coffee \n");
		
		//Creating Scanner Object
		Scanner input = new Scanner(System.in);
		String firstAnswer = input.nextLine();
		
		//Initial quit test - will come back to change this
		if(firstAnswer.equalsIgnoreCase("q")) {
			System.out.println("Test Sucess");
		}
	}

}
