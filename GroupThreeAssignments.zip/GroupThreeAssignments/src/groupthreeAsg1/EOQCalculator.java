package groupthreeAsg1;
import java.lang.Math;

public class EOQCalculator {
	double demand; 
	double unitCost; 
	double orderCost; 
	double holdingCost;
	double orderQuantity;
	
	EOQCalculator() {
		
	}
	
	EOQCalculator(double D, double C, double K, double h, double Q) {
		demand = D;
		unitCost = C;
		orderCost = K;
		holdingCost = h;
		orderQuantity = Q;
	}
	
	//Method that calculates Q
	public double CalcQ() {
		return Math.sqrt((2*demand*orderCost)/holdingCost);
	}
	
	//Method that calculates T
	public double CalcT() {
		return orderQuantity/demand;
	}
	
	//Method that calculates TAC
	public double CalcTAC() {
		return ((orderQuantity/2)*holdingCost) + ((demand*orderCost)/orderQuantity) + (demand*unitCost);
	}
}
